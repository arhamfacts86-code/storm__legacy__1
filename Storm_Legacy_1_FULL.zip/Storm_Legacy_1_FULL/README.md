# Storm__Legacy__1

Real Free Fire tournament website + Node.js server.

## Files
- `server.js` — Node.js server, API, admin login, tournament management, registrations and password release timing.
- `index.html` — the Storm__Legacy__1 website UI.

## Render
- Runtime: Node
- Build Command: leave blank (or `echo No build needed`)
- Start Command: `node server.js`

Recommended environment variables:
- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`
- `SESSION_SECRET` (use a long random value)

The app currently stores tournament data in `storm_data.json` on the server filesystem. On hosting with ephemeral storage, this data may be lost after a restart/redeploy.
