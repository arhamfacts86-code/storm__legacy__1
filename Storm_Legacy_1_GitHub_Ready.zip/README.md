# Vortex Esports — Real Full-Stack Website

This version is **not a localStorage demo**. Tournament data and registrations are stored on the server in SQLite. Admin access uses a server-side username/password and an HttpOnly session cookie.

## Room security
- Admin enters Room ID and Room Password.
- Room ID is public immediately.
- Password is stored server-side and is not returned by the public API until **24 hours after the password is saved**.
- The browser countdown is only a display; the server is the authority.
- If the admin changes the password using the password API, the 24-hour timer resets.

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Set a strong `ADMIN_PASSWORD` and a random `SESSION_SECRET` of 32+ characters.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

## Deploy
Use a Node.js host such as Render, Railway, Fly.io, or a VPS. Set the environment variables from `.env.example`. Because this project uses SQLite, production hosting should use a persistent disk/volume for `vortex.db`, or replace the database layer with PostgreSQL/Supabase.

## Important
Before going public, enable HTTPS on the host, use a strong admin password, and back up the database. Do not put the admin password in HTML/JavaScript.
