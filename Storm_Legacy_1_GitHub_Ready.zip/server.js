import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import Database from 'better-sqlite3';
import crypto from 'crypto';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;
if (!ADMIN_PASSWORD || !SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error('Set ADMIN_PASSWORD and SESSION_SECRET (32+ chars) in environment variables.');
  process.exit(1);
}

const db = new Database(path.join(__dirname, 'vortex.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS tournaments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 mode TEXT NOT NULL,
 map TEXT NOT NULL,
 prize TEXT NOT NULL,
 date TEXT NOT NULL,
 room_id TEXT NOT NULL,
 room_password TEXT,
 password_release_at INTEGER,
 created_at INTEGER NOT NULL,
 published INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS registrations (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 tournament_id INTEGER NOT NULL,
 player_name TEXT NOT NULL,
 player_uid TEXT NOT NULL,
 team_name TEXT,
 created_at INTEGER NOT NULL,
 FOREIGN KEY(tournament_id) REFERENCES tournaments(id)
);
`);

app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'20kb'}));
app.use(express.static(path.join(__dirname,'public')));
app.use('/api/', rateLimit({windowMs:60_000,max:120,standardHeaders:true,legacyHeaders:false}));

function sign(value){return crypto.createHmac('sha256',SESSION_SECRET).update(value).digest('hex');}
function makeSession(){const payload=`${Date.now()}.${crypto.randomBytes(18).toString('hex')}`; return `${payload}.${sign(payload)}`;}
function validSession(req){const token=req.headers.cookie?.match(/vortex_session=([^;]+)/)?.[1]; if(!token)return false; const parts=token.split('.'); if(parts.length!==3)return false; const [ts,id,sig]=parts; if(Date.now()-Number(ts)>24*60*60*1000)return false; const expected=sign(`${ts}.${id}`); return crypto.timingSafeEqual(Buffer.from(sig),Buffer.from(expected));}
function auth(req,res,next){if(!validSession(req))return res.status(401).json({error:'Unauthorized'});next();}
function clean(v,max=200){return String(v??'').trim().slice(0,max);}

app.post('/api/admin/login', async (req,res)=>{
  const username=clean(req.body.username,80), password=String(req.body.password||'');
  const ok=username===ADMIN_USERNAME && await bcrypt.compare(password, await bcrypt.hash(ADMIN_PASSWORD,10));
  if(!ok)return res.status(401).json({error:'Invalid login'});
  const token=makeSession();
  res.setHeader('Set-Cookie',`vortex_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400`);
  res.json({ok:true});
});
app.post('/api/admin/logout',(req,res)=>{res.setHeader('Set-Cookie','vortex_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');res.json({ok:true});});
app.get('/api/admin/me',auth,(req,res)=>res.json({ok:true,username:ADMIN_USERNAME}));

app.get('/api/tournaments',(req,res)=>{
  const now=Date.now();
  const rows=db.prepare(`SELECT id,name,mode,map,prize,date,room_id,room_password,password_release_at,created_at FROM tournaments WHERE published=1 ORDER BY date ASC`).all();
  const data=rows.map(t=>({id:t.id,name:t.name,mode:t.mode,map:t.map,prize:t.prize,date:t.date,roomId:t.room_id, password: t.room_password && t.password_release_at && now>=t.password_release_at ? t.room_password : null, passwordReleaseAt:t.password_release_at||null, passwordLocked:Boolean(t.room_password && t.password_release_at && now<t.password_release_at)}));
  res.json(data);
});

app.post('/api/admin/tournaments',auth,(req,res)=>{
  const name=clean(req.body.name), mode=clean(req.body.mode,30), map=clean(req.body.map,50), prize=clean(req.body.prize,120), date=clean(req.body.date,60), roomId=clean(req.body.roomId,100), roomPassword=clean(req.body.roomPassword,100);
  if(!name||!mode||!map||!prize||!date||!roomId)return res.status(400).json({error:'Fill all required fields including Room ID.'});
  const created=Date.now();
  const requestedRelease=Number(req.body.passwordReleaseAt);
  const release=roomPassword ? (Number.isFinite(requestedRelease) && requestedRelease>=created ? requestedRelease : created+24*60*60*1000) : null;
  const info=db.prepare(`INSERT INTO tournaments(name,mode,map,prize,date,room_id,room_password,password_release_at,created_at,published) VALUES(?,?,?,?,?,?,?,?,?,1)`).run(name,mode,map,prize,date,roomId,roomPassword||null,release,created);
  res.json({ok:true,id:info.lastInsertRowid,passwordReleaseAt:release});
});

app.put('/api/admin/tournaments/:id/password',auth,(req,res)=>{
  const id=Number(req.params.id), pass=clean(req.body.roomPassword,100);
  const now=Date.now(); const requestedRelease=Number(req.body.passwordReleaseAt);
  const release=pass ? (Number.isFinite(requestedRelease) && requestedRelease>=now ? requestedRelease : now+24*60*60*1000) : null;
  const info=db.prepare('UPDATE tournaments SET room_password=?, password_release_at=? WHERE id=?').run(pass||null,release,id);
  if(!info.changes)return res.status(404).json({error:'Tournament not found'});
  res.json({ok:true,passwordReleaseAt:release});
});
app.post('/api/admin/tournaments/:id/release',auth,(req,res)=>{ const id=Number(req.params.id); const now=Date.now(); const info=db.prepare('UPDATE tournaments SET password_release_at=? WHERE id=? AND room_password IS NOT NULL').run(now,id); if(!info.changes)return res.status(404).json({error:'Tournament or password not found'}); res.json({ok:true,passwordReleaseAt:now}); });
app.delete('/api/admin/tournaments/:id',auth,(req,res)=>{const id=Number(req.params.id); db.prepare('DELETE FROM registrations WHERE tournament_id=?').run(id); const x=db.prepare('DELETE FROM tournaments WHERE id=?').run(id); if(!x.changes)return res.status(404).json({error:'Tournament not found'});res.json({ok:true});});

app.post('/api/tournaments/:id/register',(req,res)=>{
  const id=Number(req.params.id), playerName=clean(req.body.playerName,80), playerUid=clean(req.body.playerUid,80), teamName=clean(req.body.teamName,80);
  if(!playerName||!playerUid)return res.status(400).json({error:'Player name and UID are required.'});
  const t=db.prepare('SELECT id FROM tournaments WHERE id=? AND published=1').get(id); if(!t)return res.status(404).json({error:'Tournament not found'});
  db.prepare('INSERT INTO registrations(tournament_id,player_name,player_uid,team_name,created_at) VALUES(?,?,?,?,?)').run(id,playerName,playerUid,teamName,Date.now());
  res.json({ok:true});
});

app.get('/api/admin/registrations/:id',auth,(req,res)=>{const id=Number(req.params.id);res.json(db.prepare('SELECT id,player_name as playerName,player_uid as playerUid,team_name as teamName,created_at as createdAt FROM registrations WHERE tournament_id=? ORDER BY id DESC').all(id));});

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Vortex Esports running on port ${PORT}`));
